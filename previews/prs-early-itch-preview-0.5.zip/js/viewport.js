export class viewport {
    static width = 30;
    init() {
    }
}
export default viewport;
