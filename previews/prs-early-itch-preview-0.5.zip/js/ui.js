var ui;
(function (ui) {
    function new_widget() {
    }
    ui.new_widget = new_widget;
})(ui || (ui = {}));
export default ui;
