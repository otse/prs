// allows you to venture far from import hell
// by letting you assign arbitrary values
var glob = {};
export default glob;
